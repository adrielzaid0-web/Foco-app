package com.example.foco

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var warn: Button
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(8))
        }
        status = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(8)) }
        warn = Button(this).apply {
            text = "Activar permiso de accesibilidad"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("+30 min" to 30, "+1 h" to 60, "+2 h" to 120).forEach { (t, m) ->
            row.addView(Button(this).apply {
                text = t
                setOnClickListener { Prefs.addMinutes(this@MainActivity, m); refresh() }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val hint = TextView(this).apply { text = "Apps a bloquear:"; setPadding(0, dp(12), 0, dp(4)) }

        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        val list = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_MULTIPLE
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_multiple_choice, apps.map { it.second })
        }
        val saved = Prefs.blocked(this)
        apps.forEachIndexed { i, a -> list.setItemChecked(i, a.first in saved) }
        list.setOnItemClickListener { _, _, _, _ ->
            val sel = apps.indices.filter { list.isItemChecked(it) }.map { apps[it].first }.toSet()
            Prefs.setBlocked(this, sel)
        }

        root.addView(status); root.addView(warn); root.addView(row); root.addView(hint)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName)
    }

    private fun refresh() {
        warn.visibility = if (serviceOn()) android.view.View.GONE else android.view.View.VISIBLE
        val left = Prefs.until(this) - System.currentTimeMillis()
        status.text = if (left > 0) {
            val s = left / 1000
            "🔒 Foco activo: %d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        } else "Foco apagado"
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }
}
